# youtube-link-scanner
Quick and dirty WP plugin to scan all posts for missing, broken, low-view, and copyright-flagged videos.

Note:  A YouTube API is required for this plugin.

To use:
1.  Upload the contents of this repo to your /wp-content/plugins folder on your hosting platform.
2.  Go to your plugins admin panel in WordPress and Activate the plugin
3.  Look for YouTube Scanner link on the left admin-menu...click to open.
4.  Enter your YT API ID and press save.  If there is a problem with your API, the plugin will let you know.
5.  Press Start Scan.  Any posts containing videos that are missing, broken, low-view, or copyright-flagged will be linked in the results list.
